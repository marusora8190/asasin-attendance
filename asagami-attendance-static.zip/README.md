# 朝神出欠記録（⑥ / 単一HTMLファイル版）

①〜⑤と同じ「単一HTMLファイル＋Supabase JS(CDN)」方式で作った、
ビルド不要バージョンです。更新も①〜⑤と同じく、GitHubのアップロード用URLに
`index.html` をドラッグ＆ドロップするだけで反映されます。

## 構成

```
asagami-attendance/
├── index.html                          ← これ1枚がアプリ本体（GitHubにアップロードするのはこれだけ）
└── supabase/
    ├── 0001_init_asagami.sql                        ← スパーベースに追加するテーブル・関数
    ├── 0002_import_existing_data.sql                ← 元Excelの名簿・出欠実績の移行データ
    ├── 0003_remove_anonymous_auth_requirement.sql   ← 旧バージョンをすでに実行済みの場合のみ実行
    ├── 0004_fix_pgcrypto_search_path.sql            ← 合言葉変更でエラーが出た場合に実行
    └── 0005_departments_positions_master.sql        ← 部署・立場の一覧管理を追加
```

## セットアップ手順

### 1. スパーベース（②③④⑤共用プロジェクト）にテーブルを追加する

1. https://supabase.com/dashboard/project/zhxuntrhxnrssqpvcmvl/sql/new を開く
   （aotosan1046@gmail.com でログイン）
2. `supabase/0001_init_asagami.sql` の中身をすべて貼り付けて実行
   - テーブル名はすべて `asagami_` で始まるため、②③④⑤の既存テーブル
     （items / lending_records / expense_requests / payments / waste_records など）
     とは重複しません
   - 合言葉が合っていれば直接データベースを読み書きできる、②③④⑤と同じ
     シンプルな方式にしています（Supabaseの匿名サインイン機能は使いません）
3. 続けて `supabase/0002_import_existing_data.sql` を実行
   - 元Excel「朝神出欠記録」の51名分の名簿と、入力済みだった出欠実績が入ります

※ 以前のバージョンですでに `0001_init_asagami.sql` を実行し、
　「Anonymous Sign-ins」の設定を探していた方は、代わりに
　`supabase/0003_remove_anonymous_auth_requirement.sql` を追加で実行してください
　（匿名サインインを必須にしていた古い権限設定を、合言葉だけで読み書きできる
　方式に更新するパッチです。あわせて `index.html` も新しいものに差し替えてください）。

### 2. 合言葉を変更する

初期値は `shinden2024` です。SQL Editorで以下を実行して変更してください。

```sql
select asagami_set_password('あなたの合言葉');
```

※「function gen_salt(unknown) does not exist」というエラーが出た場合は、
　先に `supabase/0004_fix_pgcrypto_search_path.sql` を実行してから、
　もう一度上記を実行してください。

### 3. GitHubリポジトリを作る

1. GitHubで新しいリポジトリ `asasin-attendance` を作成（Public）
2. リポジトリの「Add file → Upload files」、または下記URLを直接開いて
   `index.html` をドラッグ＆ドロップでアップロード
   ```
   https://github.com/【あなたのアカウント名】/asasin-attendance/upload/main
   ```
3. リポジトリの **Settings → Pages** で、Source を
   「Deploy from a branch」、Branch を `main` / `(root)` に設定
4. 数分待つと、以下のURLで公開されます
   ```
   https://【あなたのアカウント名】.github.io/asasin-attendance/
   ```

以降の更新も、修正した `index.html` を同じアップロード用URLに
ドラッグ＆ドロップし直すだけで反映されます（①〜⑤と同じ運用です）。

## Supabase接続情報の埋め込みについて

①〜⑤と同じく、`index.html` の中に直接 Supabase の URL と anonキーを
埋め込んでいます（`.env` やビルド手順は不要です）。anonキーは公開しても
問題ない仕組み（RLS = Row Level Security）になっているため、①〜⑤と
同様の安全性です。

## 機能（Web版・React版からの引き継ぎ内容）

- 出欠入力（メンバー管理・年度管理・朝神／月例参拝の切替・自動集計）
  - 部署・立場は自由入力ではなく一覧から選択する方式（「部署を編集」「立場を編集」
    ボタンから、名称の追加・変更・削除が可能。名前を変更すると、すでに割り当て
    済みのメンバーの表示も自動的に置き換わります）
- 朝神提出（月次報告書）
  - B5サイズ・見開き2ページ・押印欄つきで、元Excelの「神殿掃除実施報告書」と
    同じレイアウトを再現（実データで検証済み）
  - 印刷ダイアログでB5・両面印刷を選択してください
- 当番表（部署ごとの名簿＋その月の出欠、印刷対応）
- 合言葉1つでの簡易ログイン

## 今後について

- GitHub Actions（自動休止対策の「Keep Supabase Awake」）は、
  ②③④⑤と同じスパーベースを使っているため、②のワークフローが
  すでに⑥もカバーしています。新しい設定は不要です。
- バックアップも、②③④⑤と同じ手順（Table Editor → Export data to CSV）で、
  `asagami_members` ・ `asagami_attendance` ・ `asagami_fiscal_years` を
  対象に加えるだけで対応できます。
