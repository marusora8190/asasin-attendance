-- ============================================================
-- 朝神出欠記録（⑥）- 匿名サインイン不要化パッチ
-- 0001_init_asagami.sql をすでに実行済みの場合は、これを追加で
-- 実行してください（0001が未実行なら、この内容は0001に反映済みの
-- 最新版を使うので、0003は実行不要です）。
--
-- 変更内容：
--   これまでは書き込み（追加・編集・削除）に Supabase の匿名サインイン
--   （auth.role() = 'authenticated'）を必須にしていましたが、②③④⑤と
--   同様に「合言葉さえ通ればそのままデータベースを読み書きできる」
--   よりシンプルな方式に変更します。
-- ============================================================

drop policy if exists "asagami_fiscal_years_write" on asagami_fiscal_years;
create policy "asagami_fiscal_years_write" on asagami_fiscal_years
  for all using (true) with check (true);

drop policy if exists "asagami_members_write" on asagami_members;
create policy "asagami_members_write" on asagami_members
  for all using (true) with check (true);

drop policy if exists "asagami_attendance_write" on asagami_attendance;
create policy "asagami_attendance_write" on asagami_attendance
  for all using (true) with check (true);
