-- ============================================================
-- 朝神出欠記録（⑥）- 部署・立場マスタの追加
-- 「部署」「立場」を自由入力ではなく、一覧から選んで管理できるようにします。
-- SQL Editor でこの内容を実行してください。
-- ============================================================

create table if not exists asagami_departments (
  id serial primary key,
  name text not null unique,
  sort_order int not null default 0
);

create table if not exists asagami_positions (
  id serial primary key,
  name text not null unique,
  sort_order int not null default 0
);

alter table asagami_departments enable row level security;
alter table asagami_positions enable row level security;

create policy "asagami_departments_select" on asagami_departments for select using (true);
create policy "asagami_departments_write" on asagami_departments for all using (true) with check (true);

create policy "asagami_positions_select" on asagami_positions for select using (true);
create policy "asagami_positions_write" on asagami_positions for all using (true) with check (true);

-- 既存メンバーに登録されている部署・立場を、そのままマスタに取り込む
insert into asagami_departments (name, sort_order)
select department, row_number() over (order by min(sort_order))
from asagami_members
where department is not null and department <> ''
group by department
on conflict (name) do nothing;

insert into asagami_positions (name, sort_order)
select position, row_number() over (order by min(sort_order))
from asagami_members
where position is not null and position <> ''
group by position
on conflict (name) do nothing;
