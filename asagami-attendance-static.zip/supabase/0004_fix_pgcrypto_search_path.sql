-- ============================================================
-- 朝神出欠記録（⑥）- pgcrypto の場所を関数から見えるように修正
-- 「function gen_salt(unknown) does not exist」というエラーが出た場合に
-- 実行してください。
--
-- 原因：このプロジェクトでは pgcrypto（暗号化機能）が "extensions" と
-- いう場所にインストールされているため、関数の中の検索範囲に
-- "extensions" を加える必要があります。
-- ============================================================

create or replace function asagami_verify_password(input_password text)
returns boolean
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  stored_hash text;
begin
  select password_hash into stored_hash from asagami_config where id = true;
  if stored_hash is null then
    return false;
  end if;
  return crypt(input_password, stored_hash) = stored_hash;
end;
$$;

grant execute on function asagami_verify_password(text) to anon, authenticated;

create or replace function asagami_set_password(new_password text)
returns void
language plpgsql
security definer
set search_path = public, extensions
as $$
begin
  update asagami_config set password_hash = crypt(new_password, gen_salt('bf')) where id = true;
end;
$$;
