-- ============================================================
-- 朝神出欠記録（⑥）- スパーベース（②③④⑤共用プロジェクト）追加分
-- プロジェクト: スパーベース (zhxuntrhxnrssqpvcmvl)
-- 既存の②③④⑤のテーブルとは名前が重ならないよう、
-- すべてのテーブル・関数に asagami_ の接頭辞を付けています。
-- SQL Editor でこの内容をそのまま実行してください。
-- ============================================================

create extension if not exists pgcrypto;

-- ------------------------------------------------------------
-- 1. アプリ設定（共有パスワードのハッシュ）
-- ------------------------------------------------------------
create table if not exists asagami_config (
  id boolean primary key default true check (id),
  password_hash text not null
);

alter table asagami_config enable row level security;

-- 初期パスワードは "shinden2024" です。必ず変更してください（README参照）。
insert into asagami_config (id, password_hash)
values (true, crypt('shinden2024', gen_salt('bf')))
on conflict (id) do nothing;

create or replace function asagami_verify_password(input_password text)
returns boolean
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  stored_hash text;
begin
  select password_hash into stored_hash from asagami_config where id = true;
  if stored_hash is null then
    return false;
  end if;
  return crypt(input_password, stored_hash) = stored_hash;
end;
$$;

grant execute on function asagami_verify_password(text) to anon, authenticated;

create or replace function asagami_set_password(new_password text)
returns void
language plpgsql
security definer
set search_path = public, extensions
as $$
begin
  update asagami_config set password_hash = crypt(new_password, gen_salt('bf')) where id = true;
end;
$$;

-- ------------------------------------------------------------
-- 2. 年度マスタ
-- ------------------------------------------------------------
create table if not exists asagami_fiscal_years (
  id serial primary key,
  label text not null,
  start_reiki_year int not null unique,
  is_current boolean not null default false,
  created_at timestamptz not null default now()
);

alter table asagami_fiscal_years enable row level security;

create policy "asagami_fiscal_years_select" on asagami_fiscal_years
  for select using (true);
create policy "asagami_fiscal_years_write" on asagami_fiscal_years
  for all using (true) with check (true);

-- ------------------------------------------------------------
-- 3. メンバー
-- ------------------------------------------------------------
create table if not exists asagami_members (
  id serial primary key,
  sort_order int not null,
  department text not null default '',
  name text not null default '',
  position text not null default '',
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

alter table asagami_members enable row level security;

create policy "asagami_members_select" on asagami_members
  for select using (true);
create policy "asagami_members_write" on asagami_members
  for all using (true) with check (true);

-- ------------------------------------------------------------
-- 4. 出欠記録
--    category: 'asagami' = 朝神 / 'geppai' = 月例参拝
--    month_seq: 1〜12（1=4月 ... 9=12月 10=1月 11=2月 12=3月）
-- ------------------------------------------------------------
create table if not exists asagami_attendance (
  id serial primary key,
  member_id int not null references asagami_members(id) on delete cascade,
  fiscal_year_id int not null references asagami_fiscal_years(id) on delete cascade,
  category text not null check (category in ('asagami', 'geppai')),
  month_seq int not null check (month_seq between 1 and 12),
  status text check (status in ('○', '×')),
  updated_at timestamptz not null default now(),
  unique (member_id, fiscal_year_id, category, month_seq)
);

alter table asagami_attendance enable row level security;

create policy "asagami_attendance_select" on asagami_attendance
  for select using (true);
create policy "asagami_attendance_write" on asagami_attendance
  for all using (true) with check (true);

-- ------------------------------------------------------------
-- 5. サンプルの年度データ
-- ------------------------------------------------------------
insert into asagami_fiscal_years (label, start_reiki_year, is_current)
values ('立教189年4月〜190年3月', 189, true)
on conflict (start_reiki_year) do nothing;
