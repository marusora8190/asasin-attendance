-- 朝神出欠記録（⑥）: 既存Excelデータの移行用SQL（スパーベース用）
-- 0001_init_asagami.sql 実行後に、SQL Editor でこの内容を実行してください。

insert into asagami_fiscal_years (label, start_reiki_year, is_current)
values ('立教189年4月～立教190年3月', 189, true)
on conflict (start_reiki_year) do update set label = excluded.label, is_current = excluded.is_current;

do $$
declare
  fy_id int;
  new_member_id int;
begin
  select id into fy_id from asagami_fiscal_years where start_reiki_year = 189 limit 1;

  -- No.1: 増野 正志
  insert into asagami_members (sort_order, department, name, position)
  values (1, '営繕課', '増野 正志', '営繕課長')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.2: 北村 富美男
  insert into asagami_members (sort_order, department, name, position)
  values (2, '鉄工班', '北村 富美男', '特別ひのきしん者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.3: 柳幸 誠正
  insert into asagami_members (sort_order, department, name, position)
  values (3, '空調衛生係', '柳幸 誠正', '特別ひのきしん者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.4: 岡部　 宏
  insert into asagami_members (sort_order, department, name, position)
  values (4, '製材班', '岡部　 宏', '嘱託')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.5: 青木 年朗
  insert into asagami_members (sort_order, department, name, position)
  values (5, '庶務係', '青木 年朗', '嘱託')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.6: 田邊 克彦
  insert into asagami_members (sort_order, department, name, position)
  values (6, '製材班', '田邊 克彦', '嘱託')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.7: 桐原 裕二
  insert into asagami_members (sort_order, department, name, position)
  values (7, '現場第三班', '桐原 裕二', '嘱託')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.8: 阪本 江司
  insert into asagami_members (sort_order, department, name, position)
  values (8, '鉄工班', '阪本 江司', '嘱託')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.9: 小川 裕士
  insert into asagami_members (sort_order, department, name, position)
  values (9, '現場第三班', '小川 裕士', '嘱託')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.10: 小松 德朗
  insert into asagami_members (sort_order, department, name, position)
  values (10, '現場第一班', '小松 德朗', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.11: 和田 良二
  insert into asagami_members (sort_order, department, name, position)
  values (11, '庶務係', '和田 良二', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.12: 森脇 彰彦
  insert into asagami_members (sort_order, department, name, position)
  values (12, '現場第一班', '森脇 彰彦', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.13: 福田　 忍
  insert into asagami_members (sort_order, department, name, position)
  values (13, '鉄工班', '福田　 忍', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.14: 𠮷田 志朗
  insert into asagami_members (sort_order, department, name, position)
  values (14, '現場第三班', '𠮷田 志朗', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.15: 金子　 玲
  insert into asagami_members (sort_order, department, name, position)
  values (15, '庶務係', '金子　 玲', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.16: 横山 百歳
  insert into asagami_members (sort_order, department, name, position)
  values (16, '現場第一班', '横山 百歳', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.17: 長谷川 喜士
  insert into asagami_members (sort_order, department, name, position)
  values (17, '製材班', '長谷川 喜士', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.18: 古川 靖浩
  insert into asagami_members (sort_order, department, name, position)
  values (18, '現場第三班', '古川 靖浩', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.19: 𠮷岡 栄二郎
  insert into asagami_members (sort_order, department, name, position)
  values (19, '空調衛生係', '𠮷岡 栄二郎', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.20: 松田 博次
  insert into asagami_members (sort_order, department, name, position)
  values (20, '木工班', '松田 博次', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.21: 中嶋 理一郎
  insert into asagami_members (sort_order, department, name, position)
  values (21, '庶務係', '中嶋 理一郎', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.22: 藤咲 洋平
  insert into asagami_members (sort_order, department, name, position)
  values (22, '木工班', '藤咲 洋平', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.23: 渡邊 正道
  insert into asagami_members (sort_order, department, name, position)
  values (23, '製材班', '渡邊 正道', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.24: 白神 秀文
  insert into asagami_members (sort_order, department, name, position)
  values (24, '製材班', '白神 秀文', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.25: 安本 　明
  insert into asagami_members (sort_order, department, name, position)
  values (25, '現場第一班', '安本 　明', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.26: 長谷川 剛
  insert into asagami_members (sort_order, department, name, position)
  values (26, '大工班', '長谷川 剛', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.27: 伊藤 英樹
  insert into asagami_members (sort_order, department, name, position)
  values (27, '空調衛生係', '伊藤 英樹', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.28: 今川 昭仁
  insert into asagami_members (sort_order, department, name, position)
  values (28, '現場第一班', '今川 昭仁', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.29: 福井 真治
  insert into asagami_members (sort_order, department, name, position)
  values (29, '現場第一班', '福井 真治', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.30: 小野 直宏
  insert into asagami_members (sort_order, department, name, position)
  values (30, '大工班', '小野 直宏', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.31: 林　  靖史
  insert into asagami_members (sort_order, department, name, position)
  values (31, '現場第二班', '林　  靖史', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.32: 齋藤 明男
  insert into asagami_members (sort_order, department, name, position)
  values (32, '鉄工班', '齋藤 明男', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.33: 大矢 教継
  insert into asagami_members (sort_order, department, name, position)
  values (33, '鉄工班', '大矢 教継', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.34: 川田 陽平
  insert into asagami_members (sort_order, department, name, position)
  values (34, '鉄工班', '川田 陽平', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.35: 𠮷井 幸平
  insert into asagami_members (sort_order, department, name, position)
  values (35, '空調衛生係', '𠮷井 幸平', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '×');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.36: 細谷 成己
  insert into asagami_members (sort_order, department, name, position)
  values (36, '木工班', '細谷 成己', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.37: 森本 裕次郎
  insert into asagami_members (sort_order, department, name, position)
  values (37, '大工班', '森本 裕次郎', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.38: 高場 優介
  insert into asagami_members (sort_order, department, name, position)
  values (38, '鉄工班', '高場 優介', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.39: 佐々木 徹
  insert into asagami_members (sort_order, department, name, position)
  values (39, '大工班', '佐々木 徹', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.40: 樽本 隆平
  insert into asagami_members (sort_order, department, name, position)
  values (40, '鉄工班', '樽本 隆平', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.41: 有木 直也
  insert into asagami_members (sort_order, department, name, position)
  values (41, '大工班', '有木 直也', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.42: 蒋田ﾏﾙｾﾛ勇輝
  insert into asagami_members (sort_order, department, name, position)
  values (42, '空調衛生係', '蒋田ﾏﾙｾﾛ勇輝', '勤務者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.43: 𠮷岡 恵太
  insert into asagami_members (sort_order, department, name, position)
  values (43, '現場第二班', '𠮷岡 恵太', '３年目ひのきしん者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.44: 新川 功汰
  insert into asagami_members (sort_order, department, name, position)
  values (44, '大工班', '新川 功汰', '２年目ひのきしん者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.45: 正木 健太
  insert into asagami_members (sort_order, department, name, position)
  values (45, '現場第三班', '正木 健太', '２年目ひのきしん者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.46: 新川 愛貴
  insert into asagami_members (sort_order, department, name, position)
  values (46, '鉄工班', '新川 愛貴', '２年目ひのきしん者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.47: 森谷　尚
  insert into asagami_members (sort_order, department, name, position)
  values (47, '現場第一班', '森谷　尚', '１年目ひのきしん者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.48: 村田 大忠
  insert into asagami_members (sort_order, department, name, position)
  values (48, '大工班', '村田 大忠', '１年目ひのきしん者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.49: 大村 健太朗
  insert into asagami_members (sort_order, department, name, position)
  values (49, '木工班', '大村 健太朗', '１年目ひのきしん者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.50: 前田 與廣
  insert into asagami_members (sort_order, department, name, position)
  values (50, '空調衛生係', '前田 與廣', '常傭者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '○');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '○');

  -- No.51: 和田 幹恵
  insert into asagami_members (sort_order, department, name, position)
  values (51, '製材班', '和田 幹恵', '常傭者')
  returning id into new_member_id;
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 1, '×');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 2, '×');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 3, '×');
  insert into asagami_attendance (member_id, fiscal_year_id, category, month_seq, status) values (new_member_id, fy_id, 'asagami', 4, '×');

end $$;